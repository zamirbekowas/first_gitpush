import React from "react";
import TodoListItem from "../todo-list-item";

const TodoList = ({todos}) =>{
    console.log(todos);

    const todoLabels = todos.map(({id, ...others}) =>{
        return <li key={id}> <TodoListItem {...others}  /></li>
    })
    return <ul className="list-group">{todoLabels}</ul>
}

export default TodoList;