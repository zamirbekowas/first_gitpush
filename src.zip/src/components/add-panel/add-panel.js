import React from "react";

const AddPanel = () =>{
    return(
        <div>
            <input />
            <button className="btn btn-outline-secondary">Add Todo</button>
        </div>
    )
}

export default AddPanel
