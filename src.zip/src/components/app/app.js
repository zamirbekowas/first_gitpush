import React from "react";
import AddPanel from "../add-panel";
import AppHeader from "../app-header";
import TodoList from "../todo-list";
import "./app.css";

const App = () => {
  let todoData = [
      {
          label:"Make awesome coffee",
          important :false,
          id:1
      },
      {
          label:"Drink coffee",
          important:true,
          id:2,
      },
      {
          label:"Make exercises",
          important:false,
          id:3,
      },
      {
          label:"Have a lunch",
          important:true,
          id:4,
      }
  
]

    return (
        <div className="container">
            <AppHeader />


            <TodoList todos={todoData} />
            <AddPanel />
        </div>
    )
    
}



export default App;