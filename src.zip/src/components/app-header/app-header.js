import React from "react";

const AppHeader = () =>{
    return <h1>React app todo list</h1>
}
export default AppHeader;