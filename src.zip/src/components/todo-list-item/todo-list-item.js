import React from "react";

const TodoListItem = ({label,important}) =>{

    let style = {
        color:important ? "green":"blue",
        fontSize:"20px"
    };
    return <span style={style}>{label}</span>
}

export default TodoListItem